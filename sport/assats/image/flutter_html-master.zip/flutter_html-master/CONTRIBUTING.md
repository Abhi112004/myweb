Thanks for your interest in contributing to `flutter_html`!

Please see the contribution guide in the wiki: https://github.com/Sub6Resources/flutter_html/wiki/Contributing
