# flutter_html_all

All optional flutter_html widgets, bundled into a single package.

This package is simply a convenience package that exports all the other external packages. You should use this if you plan to activate all the renders that require external dependencies.
