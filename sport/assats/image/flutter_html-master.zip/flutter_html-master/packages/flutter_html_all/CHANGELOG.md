## 3.0.0-beta.2

 - Update a dependency to the latest release.

## 3.0.0-beta.1

 - Migrate from `customRender` to `Extension`

## 3.0.0-alpha.6

 - Update a dependency to the latest release.

## [3.0.0-alpha.2] - January 5, 2022:
* Initial modularized flutter_html release; use flutter_html_all for full tag support or flutter_html for just the basics 
