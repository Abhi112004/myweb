---
name: Feature request
about: Suggest an idea for flutter_html
title: "[FEATURE]"
labels: enhancement
assignees: ''

---

<!--- 

Please do not delete this issue template as it helps us organize and easily work on issues!!

NOTE: Before posting, please make sure you have
 1. Searched the README
 2. Searched the Issues tab for similar feature requests
 --->
 
**Describe your feature request**
<!--- Please provide a clear and concise description of the feature request --->

**Additional context**
<!--- Any other info relevant to the feature request, otherwise please delete --->

**A picture of a cute animal (not mandatory but encouraged)**
<!--- A picture of a cute animal that would nicely complement this feature request. 
If you don't have one, please delete, just know we will be a little disappointed ;) --->